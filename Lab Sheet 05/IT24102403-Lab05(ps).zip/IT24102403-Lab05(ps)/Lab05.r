setwd("C:\\Users\\MSI\\Desktop\\IT24102403-Lab05(ps)")

#1
Delivery_Times <- read.table ("Exercise - Lab 05.txt" , header = TRUE)
fix(Delivery_Times)


#2
hist(Delivery_Times$Delivery_Time_,
              main = "Histogram of Delivery Times" ,
              xlab = "Delivery Time(minutes)" ,
              ylab = "Frequency" ,
              breaks = seq(20 , 70 , length = 10) ,
              right = FALSE )

#4
histogram <- hist(Delivery_Times$Delivery_Time_,
                  breaks = seq(20 , 70 , length = 10) ,
                  right = FALSE ,
                  plot = FALSE)
cum_freq <- cumsum(histogram$counts)
breaks <- histogram$breaks

cum_breaks <- c(breaks[1] , breaks[-1])
cum_freq <- c(0 , cum_freq)

plot(cum_breaks , cum_freq , type='l' , main = "Cumulative frequency polygon" , 
     xlab = "Delivery Time (minutes)", 
     ylab = "Cumulative Frequency")
points (cum_breaks , cum_freq , pch = 19 , col = "red")

