setwd("C:\\Users\\MSI\\Desktop\\IT24102403 - Lab06(PS)")

# (1)

#i. binomial distribution

#ii.
pbinom(46,50,0.85,lower.tail =FALSE)

#(2)

#i. number of customer calls per hour

#ii. poisson distribution

#iii.|
dpois(15,12)